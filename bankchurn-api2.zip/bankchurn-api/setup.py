from setuptools import setup, find_packages

setup(
    name="model_abandono",
    version="0.0.2",
    packages=find_packages(),
    install_requires=[
        "pandas>=1.0.0",
        "numpy>=1.18.0",
        "fastapi>=0.88.0,<1.0.0",
        "uvicorn>=0.20.0,<0.30.0",
        "pydantic>=1.10.0,<2.0.0"
    ],
)
